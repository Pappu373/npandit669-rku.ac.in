﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hostel_management_system
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (ValidateFields())
            {
                // If txtId is not empty, it means we're updating a record
                if (!string.IsNullOrWhiteSpace(txtId.Text))
                {
                    // Call update method if an ID is present
                    UpdateDataInDatabase(int.Parse(txtId.Text));
                }
                else
                {
                    // Otherwise, it's a new record, so call the save method
                    SaveDataToDatabase();
                }
            }

        }

        private bool ValidateFields()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtMobile.Text) ||
                string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(txtDOB.Text) ||
                comGender.SelectedIndex == -1)
            {
                MessageBox.Show("All fields are required", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void SaveDataToDatabase()
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";

            // SQL insert query
            string query = "INSERT INTO Student (Name, Email, Gender, Mobile, Address, DOB) VALUES (@Name, @Email, @Gender, @Mobile, @Address, @DOB)";

            // Create a connection to the database
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // Create a command using the query and connection
                    SqlCommand cmd = new SqlCommand(query, con);

                    // Set parameters to avoid SQL injection
                    cmd.Parameters.AddWithValue("@Name", txtName.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Gender", comGender.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@DOB", DateTime.Parse(txtDOB.Text)); // Parse DOB string to DateTime

                    // Open the connection
                    con.Open();

                    // Execute the insert command
                    int result = cmd.ExecuteNonQuery();

                    // Check if insert was successful
                    if (result > 0)
                    {
                        MessageBox.Show("Data saved successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Data not saved.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }

            }


        }
        private void ClearFields()
        {
            // Clear all text boxes
            txtName.Text = "";
            txtEmail.Text = "";
            txtMobile.Text = "";
            txtAddress.Text = "";
            txtDOB.Text = "";

            // Reset combo box
            comGender.SelectedIndex = -1;
        }

        private void UpdateDataInDatabase(int userId)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";

            // SQL update query
            string query = "UPDATE Student SET Name = @Name, Email = @Email, Gender = @Gender, Mobile = @Mobile, Address = @Address, DOB = @DOB WHERE Id = @Id";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, con);

                    // Set parameters to avoid SQL injection
                    cmd.Parameters.AddWithValue("@Name", txtName.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Gender", comGender.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@DOB", DateTime.Parse(txtDOB.Text));
                    cmd.Parameters.AddWithValue("@Id", userId); // Pass the Id of the user to update

                    // Open connection
                    con.Open();

                    // Execute the update command
                    int result = cmd.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Data updated successfully!");
                        ClearFields(); // Clear form fields after updating
                    }
                    else
                    {
                        MessageBox.Show("Data not updated.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (ValidateFields())
            {
                if (!string.IsNullOrWhiteSpace(txtId.Text)) // If ID is present, update
                {
                    UpdateDataInDatabase(int.Parse(txtId.Text));
                }
                else
                {
                    MessageBox.Show("No record selected for update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtId.Text)) // Check if ID is present
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dialogResult == DialogResult.Yes)
                {
                    // Call method to delete the data from the database
                    DeleteDataFromDatabase(int.Parse(txtId.Text));
                }
            }
            else
            {
                MessageBox.Show("No record selected for deletion.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void DeleteDataFromDatabase(int userId)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";
            string query = "DELETE FROM Student WHERE Id = @Id";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Id", userId); // Use the Id to delete the correct record

                    // Open connection
                    con.Open();

                    // Execute the delete command
                    int result = cmd.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Record deleted successfully!");
                        ClearFields(); // Clear form fields after deletion
                    }
                    else
                    {
                        MessageBox.Show("Record not found or not deleted.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 Form = new Form1();

            Form.Show();
            this.Hide();
        }
    }
}
