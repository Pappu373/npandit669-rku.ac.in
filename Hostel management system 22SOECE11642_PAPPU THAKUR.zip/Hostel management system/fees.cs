﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Hostel_management_system
{
    public partial class fees : Form
    {
        public fees()
        {
            InitializeComponent();
        }

        private void fees_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Capture the input values
            string name1 = name.Text;
            string email = emailid.Text;
            string number = mobilenumber.Text;
            string number1 = roomnumber.Text;
            string month1 = month.SelectedItem != null ? month.SelectedItem.ToString() : "";
            string amount = duesamount.Text;

            // Connection string (make sure to update this to match your database)
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";

            // SQL Insert Query
            if (string.IsNullOrWhiteSpace(name.Text) ||
                string.IsNullOrWhiteSpace(emailid.Text) ||
                string.IsNullOrWhiteSpace(mobilenumber.Text) ||
                string.IsNullOrWhiteSpace(roomnumber.Text) ||
                string.IsNullOrWhiteSpace(duesamount.Text) ||
                month.SelectedIndex == -1) // No month is selected
            {
                MessageBox.Show("All fields are required. Please fill out the entire form.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string query = "INSERT INTO fees (Name, Emailid, Mobilenumber, Roomnumber, Month, Duesamount) VALUES (@Name, @Emailid, @Mobilenumber, @Roomnumber, @Month, @Duesamount)";

                try
                {
                    // Database connection and execution
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(query, con))
                        {
                            // Add parameters to prevent SQL injection
                            cmd.Parameters.AddWithValue("@Name", name1);
                            cmd.Parameters.AddWithValue("@Emailid", email);
                            cmd.Parameters.AddWithValue("@Mobilenumber", number);
                            cmd.Parameters.AddWithValue("@Roomnumber", number1);
                            cmd.Parameters.AddWithValue("@Month", month1);
                            cmd.Parameters.AddWithValue("@Duesamount", amount);

                            // Open the connection and execute the query
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();

                            // Success message
                            MessageBox.Show("Paid successfully!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Display error message if something goes wrong
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Clear all text fields
            name.Text = "";
            emailid.Text = "";
            mobilenumber.Text = "";
            roomnumber.Text = "";

            // Reset the ComboBox to no selection
            month.SelectedIndex = -1;

            // Clear the dues amount field
            duesamount.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 Form = new Form1();

            Form.Show();
            this.Hide();
        }
    }
}
