﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostel_management_system
{
    public partial class employee : Form
    {
        public employee()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ValidateFields())
            {
                InsertEmployeeData();
            }
        }


        private bool ValidateFields()
        {
            if (string.IsNullOrWhiteSpace(txtEmployeeName.Text) ||
                string.IsNullOrWhiteSpace(txtEmployeeEmail.Text) ||
                string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(txtSalary.Text) ||
                cmbGender.SelectedIndex == -1)
            {
                MessageBox.Show("All fields are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void InsertEmployeeData()
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";
            string query = "INSERT INTO Employee1 (EmployeeName, EmployeeEmail, Gender, Address, Salary) VALUES (@EmployeeName, @EmployeeEmail, @Gender, @Address, @Salary)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@EmployeeName", txtEmployeeName.Text);
                    cmd.Parameters.AddWithValue("@EmployeeEmail", txtEmployeeEmail.Text);
                    cmd.Parameters.AddWithValue("@Gender", cmbGender.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@Salary", decimal.Parse(txtSalary.Text)); // Parse salary to decimal

                    con.Open();

                    int result = cmd.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Employee data inserted successfully!");
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Data not inserted.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void ClearFields()
        {
            txtEmployeeName.Text = "";
            txtEmployeeEmail.Text = "";
            txtAddress.Text = "";
            txtSalary.Text = "";
            cmbGender.SelectedIndex = -1;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Form1 Form = new Form1();

            Form.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtEmployeeId.Text)) // Check if Employee ID is present
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dialogResult == DialogResult.Yes)
                {
                    // Call method to delete the employee data from the database
                    DeleteEmployeeData(int.Parse(txtEmployeeId.Text));
                }
            }
            else
            {
                MessageBox.Show("Please select or enter the employee ID to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteEmployeeData(int employeeId)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";
            string query = "DELETE FROM Employee1 WHERE EmployeeId = @EmployeeId";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@EmployeeId", employeeId); // Use EmployeeId to delete the correct record

                    // Open the connection
                    con.Open();

                    // Execute the delete command
                    int result = cmd.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Employee data deleted successfully!");
                        ClearFields(); // Clear form fields after deletion
                    }
                    else
                    {
                        MessageBox.Show("Record not found or deletion failed.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}
