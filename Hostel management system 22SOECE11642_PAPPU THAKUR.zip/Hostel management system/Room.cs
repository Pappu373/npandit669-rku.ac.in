﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostel_management_system
{
    public partial class Room : Form
    {
        public Room()
        {
            InitializeComponent();
        }

        internal void Shown()
        {
            throw new NotImplementedException();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 Form = new Form1();

            Form.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Get room number and selected option (AC/Non-AC)
            string roomNumber = number.Text;
            string roomType = ac.Checked ? "AC" : "Non-AC";

            // Ensure room number is not empty
            if (string.IsNullOrEmpty(roomNumber))
            {
                MessageBox.Show("Please enter the room number.");
                return;
            }

            // Insert data into the database
            InsertRoomData(roomNumber, roomType);
        }

        private void InsertRoomData(string roomNumber, string roomType)
        {
            // Define the connection string (modify based on your DB settings)
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";

            // SQL query to insert data
            string query = "INSERT INTO RoomInformationn (Number, Type) VALUES (@Number, @Type)";

            // Use ADO.NET to insert the data
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Number", roomNumber);
                cmd.Parameters.AddWithValue("@Type", roomType);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Room data added successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Error adding room data.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            
                // Get the current room number and the new data
                string roomNumber = NewRoom.Text; // Current room number (from the text box)
                string roomType = NAc.Checked ? "AC" : "Non-AC"; // Determine if it's AC or Non-AC

                // Validate that the room number is provided
                if (string.IsNullOrEmpty(roomNumber))
                {
                    MessageBox.Show("Please enter the room number.");
                    return;
                }

                // Call the update method to update the room data
                UpdateRoomData(roomNumber, roomType);
            }

            private void UpdateRoomData(string roomNumber, string roomType)
            {
                // Define the connection string (modify based on your DB settings)
                string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";

                // SQL query to update the room data based on the room number
                string query = "UPDATE RoomInformationn SET Type = @RoomType WHERE Number = @RoomNumber";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@RoomNumber", roomNumber);
                    cmd.Parameters.AddWithValue("@RoomType", roomType);

                    try
                    {
                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Room information updated successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Room not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

        private void button3_Click(object sender, EventArgs e)
        {
            string roomNumber = NewRoom.Text;
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\asgr\\source\\repos\\Hostel management system\\Hostel.mdf\";Integrated Security=True";
            string query = "DELETE FROM RoomInformationn WHERE Number = @RoomNumber";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@RoomNumber", roomNumber);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Room deleted successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Room not found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }


    }





